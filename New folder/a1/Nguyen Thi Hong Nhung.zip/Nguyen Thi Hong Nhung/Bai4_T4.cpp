#include<iostream>
#include<iomanip>
using namespace std ;

class Anpham
{
	public :
		string ten ;
		float gia ;
	public :
		void Nhap()
		{
			fflush(stdin);
			cout<<"Nhap ten an pham " ; getline(cin , ten) ;
			cout<<"Nhap gia thanh " ; cin>>gia ;
		}
		void in()
		{
			cout<<"|"<<setw(25)<<ten ;
			cout<<"|"<<setw(12)<<gia ;
			
		}
		
} ;
class Sach : public Anpham
{
	public :
		int sotrang ;
	public :
		void nhap1()
		{
			Anpham::Nhap() ;
			cout<<"Nhap so trang " ; cin >> sotrang;
		}
		void in1()
		{
			Anpham::in() ;
			cout<<"|"<<setw(10)<<sotrang<<"|"<<endl ;
			cout<<"|"<<setfill('-')<<setw(50)<<"|"<<setfill(' ')<<endl ;	
		}
		bool operator > (int a)
		{
			return this->sotrang >a ;
		}
};
class Cd : public Anpham
{
	private :
		int phut ;
	public :
	void nhap2()
		{
			Anpham::Nhap() ;
			cout<<"Nhap so phut " ; cin >> phut;
		}
		void in2()
		{
			Anpham::in() ;
			cout<<"|"<<setw(10)<<phut<<"|"<<endl ;
			cout<<"|"<<setfill('-')<<setw(50)<<"|"<<setfill(' ')<<endl ;	
		}
		bool operator ==(string x)
		{
			return this->ten==x ;
		}
};
void tieude(string x)
{
	cout<<"|"<<setfill('-')<<setw(50)<<"|"<<setfill(' ')<<endl ;	
	cout<<"|"<<setw(25)<<"Ten an pham " ;
	cout<<"|"<<setw(12)<<"Gia thanh " ;
	cout<<"|"<<setw(10)<<x<<"|"<<endl ;
	cout<<"|"<<setfill('-')<<setw(50)<<"|"<<setfill(' ')<<endl ;	
	
}
int main()
{
	int n ;
	cout<<"Nhap vao so sach " ; cin >> n ;
	Sach s[n];
	for(int i=0 ; i<n ; i++)
	{
		cout<<"Nhap sach thu "<<i+1<<" :"<<endl ;
		s[i].nhap1() ;
	}
	cout<<endl ;
	cout<<"Nhung quyen sach co so trang lon hon 500 la "<<endl ;
	tieude("So trang ") ;
	for(int i= 0 ; i<n ; i++)
	{
		if(s[i]>500)
		s[i].in1() ;
	}
	
	int m ;
	cout<<"Nhap vao so dia CD " ; cin >> m ;
	 Cd c[m];
	
	for(int i=0 ; i<m ; i++)
	{
		cout<<"Nhap dia CD thu "<<i+1<<" :"<<endl ;
		c[i].nhap2() ;
	}
	cout<<endl ;
	string x ;
	fflush(stdin);
	cout<<"Nhap ten dia CD can tim " ; getline(cin,x) ;
	cout<<"Danh sach dia CD duoc tim la " <<endl ;
	tieude("So phut ") ;
	for(int i=0 ; i<m ; i++)
	{
		if(c[i]==x)
		c[i].in2() ;
	}
	
	
}

