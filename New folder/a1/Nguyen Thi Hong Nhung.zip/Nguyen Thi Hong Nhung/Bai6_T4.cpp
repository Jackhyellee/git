#include<iostream>
#include<iomanip>

using namespace std;

class PET{
	protected:
		int tuoi;
		float cn;
};
class Dog: public PET{
	private:
		string mm, st;
	public:
		friend istream& operator>>(istream& is, Dog *d){
			cout<<"Tuoi: ";		is>>d->tuoi;
			cout<<"Can nang:";	is>>d->cn;
			is.ignore();
			cout<<"Mau mat: ";	getline(is, d->mm);
			cout<<"So thich: ";	getline(is, d->st);
			return is;
		}
		friend ostream& operator<<(ostream& os, Dog *d){
			os<<"Tuoi: "<<d->tuoi<<endl;
			os<<"Can nang: "<<d->cn<<endl;
			os<<"Mau mat: "<<d->mm<<endl;
			os<<"So thich: "<<d->st<<endl;
			return os;
		}
		bool operator<(Dog *d){
			return(cn<d->cn);
		}
		bool operator>=(int a){
			return(tuoi>=a);
		}
		bool operator<=(int a){
			return(tuoi<=a);
		}
		friend float tongCanNang(Dog *d, int n);
};

int main(){
	int n;
	cout<<"Nhap so con dog : ";	cin>>n;
	Dog d[n];
	
	cout<<"_NHAP DANH SACH DOG_\n";
	for(int i=0; i<n; i++){
		cout<<"\tNhap thong tin cua chu cun thu "<<i+1<<endl;
		cin>>d+i;
	}
	cout<<"_DANH SACH DOG_\n";
	for(int i=0; i<n; i++){
		cout<<"\tThong tin cua chu cun thu "<<i+1<<endl;
		cout<<d+i;
	}
	
	cout<<"_DANH SACH DOG THEO CHIEU TANG DAN CAN NANG_\n";
	for(int i=0; i<n-1; i++){
		for(int j=i+1; j<n; j++)
			if(d+j < d+i)
				swap(*(d+i), *(d+j));
	}
	for(int i=0; i<n; i++){
		cout<<"\tThong tin chu cun tai thu"<<i+1<<endl;
		cout<<d+i;
	}
	
	cout<<"_DANH SACH DOG TU 2 DEN 5 TUOI_\n";
	for(int i=0; i<n; i++)
		if(d[i] >= 2 && d[i] <= 5){
			cout<<"\tThong tin chu cun tai vi tri "<<i+1<<endl;
			cout<<d+i;
		}
		
	cout<<"\n\n TONG CAN NANG CUA CAC CHU CUN: "<<tongCanNang(d, n);
	return 0;
}
float tongCanNang(Dog *d, int n){
	float sum =0;
	for(int i=0; i<n; i++)
		sum += d[i].cn;
	return sum;
}
