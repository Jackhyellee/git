#include<iostream>
#include<iomanip>

using namespace std;

class person{
	protected:
		string name, add, phone;
	public:
		person(){
			name = " ";
			add =" ";
			phone = " ";
		}
		person(string name, string add, string phone){
			this->name = name;
			this->add = add;
			this->phone = phone;
		}
		~person(){	}
};
class office :public person{
	protected:
		float salary;
	public:
		office(){
			salary = 0;
		}
		office(string name, string add, string phone, float salary):person(name, add, phone){
			this->salary = salary;
		}
		~office(){	}
};
class manager:public office{
	private:
		string extra;
	public:
		manager(){
			extra = " ";
		}
		manager(string name, string add, string phone, float salary, string extra):office(name, add, phone, salary){
			this->extra = extra;
		}
		~manager(){	}
		void nhap()
		{
			fflush(stdin);
			cout<<"Nhap ten " ; getline(cin,name) ;
			cout<<"Nhap dia chi " ; getline(cin,add) ;
			cout<<"Nhap so dien thoai " ; cin>>phone ;
			cout<<"Nhap luong " ; cin>>salary ;
			fflush(stdin);
			cout<<"Nhap them " ; getline(cin,extra) ;
			
			
		}
		void HienThi(){
			cout<<"|"<<setw(25)<<name;
			cout<<"|"<<setw(20)<<add;
			cout<<"|"<<setw(15)<<phone;
			cout<<"|"<<setw(10)<<salary;
			cout<<"|"<<setw(30)<<extra<<"|"<<endl;
			cout<<"+"<<setfill('-')<<setw(105)<<"+"<<setfill(' ')<<endl;
		}
		bool operator==(string x){
			return(add == x);
		}
		bool operator!=(float a){
			return(salary != a);
		}
		
};
void TieuDe();

int main(){
	int n;
	cout<<"Nhap so nha quan ly "; cin>>n;
	manager m[n];
	for(int i=0; i<n; i++)
	{
		cout<<"Quan ly thu "<<i+1<<endl ;
		m[i].nhap() ;
		
	}
	cout<<endl ;
	string x = "_DANH SACH CAC NHA QUAN LY_";
	cout<<setw((105+x.length())/2)<<x<<endl;
	TieuDe();
	for(int i=0; i<n; i++)
		m[i].HienThi();
		
	x = "_NHUNG DOI TUONG O 'HA NOI' VA LUONG KHAC 10 TRIEU_";
	cout<<endl<<setw((105+x.length())/2)<<x<<endl;
	TieuDe();
	for(int i=0; i<n; i++)
		if(m[i] == "Ha Noi" && m[i] != 10)
			m[i].HienThi();
	return 0;
}
void TieuDe(){
	cout<<"+"<<setfill('-')<<setw(105)<<"+"<<setfill(' ')<<endl;
	cout<<"|"<<setw(25)<<"Ho ten";
	cout<<"|"<<setw(20)<<"Dia chi";
	cout<<"|"<<setw(15)<<"Dien thoai";
	cout<<"|"<<setw(10)<<"Luong(Tr)";
	cout<<"|"<<setw(30)<<"Thong tin them"<<"|"<<endl;
	cout<<"+"<<setfill('-')<<setw(105)<<"+"<<setfill(' ')<<endl;
}
