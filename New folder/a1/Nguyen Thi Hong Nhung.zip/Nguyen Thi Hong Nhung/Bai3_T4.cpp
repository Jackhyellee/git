#include<iostream>
#include<string>

using namespace std;

class MatHang
{
	public:
		string mahang;
		string tenhang;
		int dongia;
	public :
		MatHang()
		{
			mahang = " ";
			tenhang = " ";
			dongia = 0 ;
		}
	
		MatHang(string mahang, string tenhang, int dongia)
		{
			this -> mahang = mahang;
			this -> tenhang = tenhang;
			this -> dongia = dongia;	
		}
			
		~MatHang(){
		}
		
		friend istream& operator >> (istream& is ,MatHang &m )
		{
			fflush(stdin);
			cout<<" Nhap ma hang: ";
			getline(is, m.mahang);
			cout<<" Nhap ten hang: ";
			getline(is, m.tenhang);
			cout<<" Nhap don gia: ";
			is>>m.dongia;
			return is ;
		}
		
	
};

class BanhKeo : public MatHang
{
	private:
		string noisanxuat;
		
	public:
		BanhKeo()
		{
			noisanxuat = " ";
		}
			
		BanhKeo(string mahang, string tenhang, int dongia, string noisanxuat) : MatHang(mahang, tenhang, dongia)
		{
			this -> noisanxuat = noisanxuat;
		}
		
		~BanhKeo(){
		}

		friend istream& operator >> (istream& is ,BanhKeo &b )
		{
			
			is>>(MatHang&)b ;
			fflush(stdin);
			cout<<" Nhap noi san xuat: ";
			getline(is, b.noisanxuat);
			return is ;
		}
		float Tinhck()
		{
			return (float) 0,01*dongia ;
		}
		friend ostream& operator << (ostream& os ,BanhKeo &b )
		{
			cout<<"\n Ma hang: "	<<b.mahang;
			cout<<"\n Ten hang: "	<<b.tenhang;
			cout<<"\n Don gia: "	<<b.dongia;
			cout<<"\n Noi san xuat: "<<b.noisanxuat;
			cout<<"\n Chiet khau : "<<b.Tinhck() ;
			return os ;
		}
};

int main()
{
	int n ;
	cout<<"Nhap so banh keo " ; cin >>n ;
	BanhKeo bk[n] ;
	for(int i=0 ; i<n ; i++)
	{
		cout<<"Benh keo thu "<< i+1<<endl  ;
		cin>>bk[i];
		
	}
	cout<<"Banh keo co ma san pham khac MO1 la "<<endl ;
	for(int i=0 ; i<n ; i++)
	{
		if(bk[i].mahang != "MO1")
		cout<<bk[i] ;
	}
	return 0;
}
