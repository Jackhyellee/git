#include<iostream>
#include<iomanip>

using namespace std;

const int namnay=2023;

class BenhNhan{
	protected:
		string ht, qq;
		int ns;
	public:
		friend istream& operator>>(istream& is, BenhNhan &bn){
			is.ignore();
			cout<<"Ho ten: ";	getline(is,bn.ht);
			cout<<"Que quan: ";	getline(is,bn.qq);
			cout<<"Nam sinh: ";	cin>>bn.ns;
			return is;
		}
		friend ostream& operator<<(ostream& os, BenhNhan &bn){
			os<<"|"<<setw(30)<<bn.ht;
			os<<"|"<<setw(20)<<bn.qq;
			os<<"|"<<setw(8)<<bn.ns;
			return os;
		}
};

class BenhAn :public BenhNhan{
	private:
		string tba;
		float vp;
	public:
		friend istream& operator>>(istream& is, BenhAn &ba){
			is>>(BenhNhan&)ba;
			is.ignore();
			cout<<"Ten benh an: ";	getline(is, ba.tba);
			cout<<"Vien phi: ";		cin>>ba.vp;
			return is;
		}
		friend ostream& operator<<(ostream& os, BenhAn & ba){
			os<<(BenhNhan&)ba;
			os<<"|"<<setw(30)<<ba.tba;
			os<<"|"<<setw(7)<<ba.vp<<"|"<<endl;
			os<<"+"<<setfill('-')<<setw(100)<<"+"<<setfill(' ')<<endl;
			return os;
		}
		int Tuoi(int namnay){
			return(namnay - ns);
		}
		bool operator<(BenhAn &ba){
			return(this->Tuoi(namnay)<ba.Tuoi(namnay));
		}
		bool operator>(BenhAn &ba){
			return(this->vp > ba.vp);
		}
};
void TieuDe();
int main(){
	int n;
	cout<<"Nhap n: ";	cin>>n;
	
	BenhAn ba[n];
	cout<<"_NHAP DANH SACH BANH AN_\n";
	for(int i=0; i<n; i++){
		cout<<"\tNhap thong tin banh an thu "<<i+1<<endl;
		cin>>ba[i];
	}
	
	cout<<"_DANH SACH BENH AN THEO TUOI BENH NHAN GIAM DAN_\n";
	TieuDe();
	BenhAn max;
	for(int i=0; i<n; i++){
		max = ba[i];
		for(int j=i+1; j<n; j++){
			if(max < ba[j])	//tuoi
				max = ba[j];
		}
		swap(ba[i], max);
		cout<<ba[i];
	}
	
	cout<<"_DANH SACH BENH NHAN TREN 50 TUOI_\n";
	TieuDe();
	for(int i=0; i<n; i++)
		if(ba[i].Tuoi(namnay) > 50)
			cout<<ba[i];
			
	cout<<"_BENH NHAN CO VIEN PHI CAO NHAT_\n";
	TieuDe();
	max = ba[0];
	for(int i=1; i<n; i++){
		if(ba[i] > max)	//vien phi
			max = ba[i];
	}
	cout<<max;
	return 0;
} 
void TieuDe(){
	cout<<"+"<<setfill('-')<<setw(100)<<"+"<<setfill(' ')<<endl;
	cout<<"|"<<setw(30)<<"Ho ten";
	cout<<"|"<<setw(20)<<"Que quan";
	cout<<"|"<<setw(8)<<"Nam sinh";
	cout<<"|"<<setw(30)<<"Ten benh an";
	cout<<"|"<<setw(7)<<"Vp"<<"|"<<endl;
	cout<<"+"<<setfill('-')<<setw(100)<<"+"<<setfill(' ')<<endl;
}
