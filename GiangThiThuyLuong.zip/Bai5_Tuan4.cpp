#include<iostream>
#include<iomanip>

using namespace std;

class person{
	protected:
		string name, add, phone;
	public:
		person(){
			name = " ";
			add =" ";
			phone = " ";
		}
		person(string name, string add, string phone){
			this->name = name;
			this->add = add;
			this->phone = phone;
		}
		~person(){	}
};
class office :public person{
	protected:
		float salary;
	public:
		office(){
			salary = 0;
		}
		office(string name, string add, string phone, float salary):person(name, add, phone){
			this->salary = salary;
		}
		~office(){	}
};
class manager:public office{
	private:
		string extra;
	public:
		manager(){
			extra = " ";
		}
		manager(string name, string add, string phone, float salary, string extra):office(name, add, phone, salary){
			this->extra = extra;
		}
		~manager(){	}
		void HienThi(){
			cout<<"|"<<setw(30)<<name;
			cout<<"|"<<setw(20)<<add;
			cout<<"|"<<setw(15)<<phone;
			cout<<"|"<<setw(10)<<salary;
			cout<<"|"<<setw(30)<<extra<<"|"<<endl;
			cout<<"+"<<setfill('-')<<setw(110)<<"+"<<setfill(' ')<<endl;
		}
		bool operator==(string x){
			return(add == x);
		}
		bool operator!=(float a){
			return(salary != a);
		}
};
void TieuDe();
void setList(manager m[], int n);
int main(){
	int n;
	cout<<"Nhap n: "; cin>>n;
	manager m[n];
	setList(m, n);
	
	string x = "_DANH SACH CAC NHA QUAN LY_";
	cout<<setw((110+x.length())/2)<<x<<endl;
	TieuDe();
	for(int i=0; i<n; i++)
		m[i].HienThi();
		
	x = "_NHUNG DOI TUONG O 'HA NOI' VA LUONG KHAC 10 TRIEU_";
	cout<<endl<<setw((110+x.length())/2)<<x<<endl;
	TieuDe();
	for(int i=0; i<n; i++)
		if(m[i] == "Ha Noi" && m[i] != 10)
			m[i].HienThi();
	return 0;
}
void TieuDe(){
	cout<<"+"<<setfill('-')<<setw(110)<<"+"<<setfill(' ')<<endl;
	cout<<"|"<<setw(30)<<"Ho ten";
	cout<<"|"<<setw(20)<<"Dia chi";
	cout<<"|"<<setw(15)<<"Dien thoai";
	cout<<"|"<<setw(10)<<"Luong(Tr)";
	cout<<"|"<<setw(30)<<"Thong tin them"<<"|"<<endl;
	cout<<"+"<<setfill('-')<<setw(110)<<"+"<<setfill(' ')<<endl;
}
void setList(manager m[], int n){
	int i=0;
	manager tg[10];
	tg[0] = manager("Thuy Kieu", "Ha Noi", "2222222222", 13, "Dien mao: xinh");
	tg[1] = manager("Nguyen Phuong Thuy", "Ha Noi", "0842354657", 10, "Khong co");
	tg[2] = manager("Pham Ngoc Thach", "Cao Bang", "0363004219", 12, "Khong co");
	tg[3] = manager("Tran Van Chau", "HCM", "0288153000", 10, "Kinh nghiem: 3 nam");
	tg[4] = manager("Giang Thi Thuy Luong", "Ha Noi", "0972954164", 8, "Hoc duoc");
	tg[5] = manager("Nguyen Manh Gioi", "Ha Noi", "0111111111", 15, "Khong co");
	tg[6] = manager("Xuan Toc Do", "Ha Noi", "0635222419", 12, "Van may: xuat sac");
	tg[7] = manager("Lao Hac", "TH. Hue", "0241202056", 5, "Dien hinh");
	tg[8] = manager("Chi Dau", "Ha Noi", "6666666666", 17, "Dien hinh");
	tg[9] = manager("Tuong Pha Thach", "Lang Son", "0999998888", 10, "Khong co");
	while(i<n){
		m[i] = tg[i];
		i++;
	}
}
