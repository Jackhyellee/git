#include<iostream>
#include<iomanip>

using namespace std;

const int ptuMax = 100;

class HangHoa{
	protected:
		string ma, th;
		float dg;
	public:
		HangHoa(string ma=" ", string th=" ", float dg=0){
			this->ma = ma;
			this->th = th;
			this->dg = dg;
		}
		~HangHoa(){	}
		void Nhap(){
			cin.ignore();
			cout<<"Ma hang hoa: ";	getline(cin, ma);
			cout<<"Ten hang: ";		getline(cin, th);
			cout<<"Don gia: ";		cin>>dg;
		}
		void Xuat(){
			cout<<"|"<<setw(15)<<ma;
			cout<<"|"<<setw(30)<<th;
			cout<<"|"<<setw(8)<<dg;//55
		}
};
class MT: public HangHoa{
	protected:
		float td;
		int sl;
	public:
		MT(string ma=" ", string th=" ", float dg=0, float td=0, int sl=0):HangHoa(ma, th, dg){
			this->td = td;
			this->sl = sl;
		}
		~MT(){	}
		friend istream& operator>>(istream& is, MT &m){
			m.Nhap();
			cout<<"Toc do: ";	is>>m.td;
			cout<<"So luong: ";	is>>m.sl;
			return is;
		}
		friend ostream& operator<<(ostream& os, MT &m){
			m.Xuat();
			os<<"|"<<setw(5)<<m.td;
			os<<"|"<<setw(5)<<m.sl;
			os<<"|"<<setw(7)<<m.ThanhTien();//20
			return os;
		}
		float ThanhTien(){
			return(sl*dg);
		}
};
class MTXT: public MT{
	private:
		float tl;
	public:
		MTXT(string ma=" ", string th=" ", float dg=0, float td=0, int sl=0, float tl=0):MT(ma, th, dg, td, sl){
			this->tl = tl;
		}
		~MTXT(){	}
		float BaoTri(){
			return(dg*5/100);
		}
		friend istream& operator>>(istream& is, MTXT &mt){
			is>>(MT&)mt;
			cout<<"Trong luong: ";	is>>mt.tl;
			return is;
		}
		friend ostream& operator<<(ostream& os, MTXT &mt){
			os<<(MT&)mt;
			os<<"|"<<setw(6)<<mt.tl;
			os<<"|"<<setw(6)<<mt.BaoTri()<<"|"<<endl;//15
			os<<"+"<<setfill('-')<<setw(90)<<"+"<<setfill(' ')<<endl;
			return os;
		}
		bool operator==(string x){
			return(ma == x);
		}
		bool operator>(MTXT &mt){
			return(td > mt.td);
		}
		bool operator<(MTXT &mt){
			return(ma < mt.ma);
		}
		friend void lietKeTen(MTXT mt[], int n);
		friend void suaThongTin(MTXT mt[], int n);
		friend void xoaBangMa(MTXT mt[], int &n);
		friend void chen(MTXT mt[], int &n);
};
void TieuDe();
void menu();
void nhapMang(MTXT mt[], int &n);
void inMang(MTXT mt[], int n);
void timMa(MTXT mt[], int n);
void tongBaoTri(MTXT mt[], int n);
void tocDoMin(MTXT mt[], int n);
void sapXep(MTXT mt[], int n);
int main(){
	MTXT mt[ptuMax];
	int   n, cn;
	nhapMang(mt, n);
	while(1){
		system("cls");
		menu();
		cout<<"\n\t\t>>Vui long nhap chuc nang: ";	cin>>cn;
		switch(cn){
			case 0:
				exit(0);
			case 1:
				nhapMang(mt, n);
				break;
			case 2:
				inMang(mt, n);
				break;
			case 3:
				timMa(mt, n);
				break;
			case 4:
				lietKeTen(mt, n);
				break;
			case 5:
				tongBaoTri(mt, n);
				break;
			case 6:
				tocDoMin(mt, n);
				break;
			case 7:
				suaThongTin(mt, n);
				break;
			case 8:
				xoaBangMa(mt, n);
				break;
			case 9:
				chen(mt, n);
				break;
			case 10:
				sapXep(mt, n);
				break;
			default:
				cout<<"\t\t\t>>Chuc nang khong hop le! Vui long nhap lai\n";
		}
	}
	return 0;
}
void nhapMang(MTXT mt[], int &n){
	system("cls");
	cout<<"Nhap n: ";	cin>>n;
	
	cout<<"_NHAP DANH SACH MAY TINH XACH TAY_\n";
	for(int i=0; i<n; i++){
		cout<<"\tNhap thong tin may tinh thu "<<i+1<<endl;
		cin>>mt[i];
	}
}
void inMang(MTXT mt[], int n){
	system("cls");
	cout<<"_DANH SACH MAY TINH XACH TAY_\n";
	TieuDe();
	for(int i=0; i<n; i++)
		cout<<mt[i];
	system("pause");
}
void timMa(MTXT mt[], int n){
	system("cls");
	string x;
	cin.ignore();
	cout<<"Nhap ma can tim: ";	getline(cin, x);
	cout<<"_THONG TIN CUA MAY TINH MA'"<<x<<"'_\n";
	int cnt=0;
	for(int i=0; i<n; i++)
		if(mt[i] == x)
			cnt++;
	if(cnt == 0)
		cout<<"Khong co may tinh mang ma '"<<x<<"' trong danh sach\n";
	else{
		TieuDe();
		for(int i=0; i<n; i++)
			if(mt[i] == x)
				cout<<mt[i];
	}
	system("pause");
}
void lietKeTen(MTXT mt[], int n){
	system("cls");
	cout<<"_LIET KE TEN CAC MAY TINH XACH TAY_\n";
	cout<<"+"<<setfill('-')<<setw(32)<<"+"<<setfill(' ')<<endl;
	cout<<"+"<<setw(30)<<"Ten may"<<" +"<<endl;
	cout<<"+"<<setfill('-')<<setw(32)<<"+"<<setfill(' ')<<endl;
	for(int i=0; i<n; i++){
		cout<<"+"<<setw(30)<<mt[i].th<<" +"<<endl;
	}
	cout<<"+"<<setfill('-')<<setw(32)<<"+"<<setfill(' ')<<endl;
	system("pause");
}
void tongBaoTri(MTXT mt[], int n){
	system("cls");
	float sum =0;
	for(int i=0; i<n; i++)
		sum +=mt[i].BaoTri();
	cout<<"TONG BAO TRI MAY TINH: "<<sum<<endl;
	system("pause");
}
void tocDoMin(MTXT mt[], int n){
	system("cls");
	cout<<"_THONG TIN MAY TINH CO TOC DO NHO NHAT_\n";
	MTXT min = mt[0];
	for(int i=1; i<n; i++)
		if(min > mt[i])
			min = mt[i];
	TieuDe();
	cout<<min;
	system("pause");
}
void suaThongTin(MTXT mt[], int n){
	system("cls");
	int a;
	cout<<"Nhap vi tri(tu 1 den "<<n<<") cua may can sua: ";	cin>>a;
	cout<<"Thong tin cua may tinh thu "<<a<<endl;
	TieuDe();
	cout<<mt[a-1];
	cout<<"\n\n\tSua lai thong tin may\n";
	cin>>mt[a-1];
	cout<<"\t>>Sua thong tin thanh cong\n";
	system("pause");
}
void xoaBangMa(MTXT mt[], int &n){
	system("cls");
	string x;
	cin.ignore();
	cout<<"Nhap ma muon xoa: ";	getline(cin, x);
	cout<<"_KIEM TRA MAY TINH MA'"<<x<<"'_\n";
	int cnt=0, chiSo;
	for(int i=0; i<n; i++)
		if(mt[i] == x){
			cnt++;
		}
	if(cnt == 0)
		cout<<"Khong co may tinh mang ma '"<<x<<"' trong danh sach\n";
	else{
		for(int i=0; i<n; i++)
		if(mt[i] == x){
			for(int j=i+1; j<n; j++)
				mt[j-1] = mt[j];
			n--; 
		}
		cout<<"\t>>Da xoa may ra khoi danh sach\n";
	}
	system("pause");
}
void chen(MTXT mt[], int &n){
	system("cls");
	int k;
	cout<<"Nhap k(tu 1 den "<<n+1<<"): ";	cin>>k;
	for(int i=n; i>k-1; i--)
		mt[i] = mt[i-1];
	n++;
	cout<<"\n\tNhap thong tin cua may tinh chen vao\n";
	cin>>mt[k-1];
	cout<<"\t>>Da chen may vao vi tri "<<k<<endl;
	system("pause");
}
void sapXep(MTXT mt[], int n){
	system("cls");
	for(int i=0; i<n-1; i++)
		for(int j =i+1; j<n; j++)
			if(mt[j] < mt[i])
				swap(mt[i], mt[j]);
	cout<<"\t>>Sap xep thanh cong\n";
	system("pause");
}
void menu(){
	cout<<"+"<<setfill('-')<<setw(70)<<"+"<<setfill(' ')<<endl;
	string x = "_MENU_";
	cout<<"+"<<setw((70+x.length())/2)<<x<<setw((70-x.length())/2)<<"+"<<endl;
	cout<<"+"<<setfill('-')<<setw(70)<<"+"<<setfill(' ')<<endl;
	x = "    1. NHAP LAI DANH SACH MAY TINH XACH TAY";
	cout<<"+"<<x<<setw(70-x.length())<<"+"<<endl;
	x = "    2. HIEN THI DANH SACH";
	cout<<"+"<<x<<setw(70-x.length())<<"+"<<endl;
	x = "    3. TIM THONG TIN THEO MA MAY";
	cout<<"+"<<x<<setw(70-x.length())<<"+"<<endl;
	x = "    4. LIET KE THEO TEN";
	cout<<"+"<<x<<setw(70-x.length())<<"+"<<endl;
	x = "    5. TONG PHI BAO TRI";
	cout<<"+"<<x<<setw(70-x.length())<<"+"<<endl;
	x = "    6. THONG TIN MAY CO TOC DO NHO NHAT";
	cout<<"+"<<x<<setw(70-x.length())<<"+"<<endl;
	x = "    7. SUA THONG TIN CUA MAY TAI VI TRI I";
	cout<<"+"<<x<<setw(70-x.length())<<"+"<<endl;
	x = "    8. XOA MAY TINH BANG MA";
	cout<<"+"<<x<<setw(70-x.length())<<"+"<<endl;
	x = "    9. CHEN MAY TINH VAO VI TRI K";
	cout<<"+"<<x<<setw(70-x.length())<<"+"<<endl;
	x = "    10. SAP XEP THEO CHIEU TANG DAN MA";
	cout<<"+"<<x<<setw(70-x.length())<<"+"<<endl;
	x = "    0. THOAT KHOI CHUONG TRINH";
	cout<<"+"<<x<<setw(70-x.length())<<"+"<<endl;
	cout<<"+"<<setfill('-')<<setw(70)<<"+"<<setfill(' ')<<endl;
}
void TieuDe(){
	cout<<"+"<<setfill('-')<<setw(90)<<"+"<<setfill(' ')<<endl;
	cout<<"|"<<setw(15)<<"Ma may";
	cout<<"|"<<setw(30)<<"Ten may";
	cout<<"|"<<setw(8)<<"Don gia";
	cout<<"|"<<setw(5)<<"TD";
	cout<<"|"<<setw(5)<<"SL";
	cout<<"|"<<setw(7)<<"Gia";
	cout<<"|"<<setw(6)<<"TL";
	cout<<"|"<<setw(6)<<"TBT"<<"|"<<endl;
	cout<<"+"<<setfill('-')<<setw(90)<<"+"<<setfill(' ')<<endl;
}
