#include<iostream>
#include<iomanip>
#include<string.h>

using namespace std;

class Anpham{
	protected:
		string ten;
		float gia;
	public:
		void Nhap(){
			cin.ignore();
			cout<<"Ten an pham: ";	getline(cin, ten);
			cout<<"Gia thanh: ";	cin>>gia;
		}
		void Xuat(){
			cout<<"|"<<setw(30)<<ten;
			cout<<"|"<<setw(14)<<gia;
		}
}; 
class Sach: public Anpham{
	private:
		int st;
	public:
		void Nhap(){
			Anpham::Nhap();
			cout<<"So trang: ";	cin>>st;
		}
		void Xuat(){
			Anpham::Xuat();
			cout<<"|"<<setw(13)<<st<<"|"<<endl;
			cout<<"+"<<setfill('-')<<setw(60)<<"+"<<setfill(' ')<<endl;
		}
		bool operator>(int a){
			return(st>a);
		}
};
class DiaCD: public Anpham{
	private:
		float sp;
	public:
		void Nhap(){
			Anpham::Nhap();
			cout<<"So phut: ";	cin>>sp;
		}
		void Xuat(){
			Anpham::Xuat();
			cout<<"|"<<setw(13)<<sp<<"|"<<endl;
			cout<<"+"<<setfill('-')<<setw(60)<<"+"<<setfill(' ')<<endl;
		}
		bool operator==(string x){
			return(ten == x);
		}
};
void TieuDe(string x);
int main(){
	//Sach
	int n;
	cout<<"Nhap n: ";	cin>>n;
	Sach s[n];
	cout<<"_NHAP DANH SACH QUYEN SACH_\n";
	for(int i=0; i<n; i++){
		cout<<"\tNhap thong tin quyen sach thu "<<i+1<<endl;
		s[i].Nhap();
	}
	cout<<"_DANH SACH QUYEN SACH CO NHIEU HON 500 TRANG_\n";
	TieuDe("So trang");
	for(int i=0; i<n; i++){
		if(s[i] > 500)
			s[i].Xuat();
	}
	
	//Dia CD
	cout<<"Nhap n: ";	cin>>n;
	DiaCD d[n];
	cout<<"_NHAP DANH SACH DIA CD_\n";
	for(int i=0; i<n; i++){
		cout<<"\tNhap thong tin dia thu "<<i+1<<endl;
		d[i].Nhap();
	}
	string x;
	cin.ignore();
	cout<<"Nhap ten dia can tim: ";	getline(cin, x);
	cout<<"_DIA CD CO TEN '"<<x<<"' TRONG DANH SACH_\n";
	TieuDe("So phut");
	for(int i=0; i<n; i++)
		if(d[i] == x)
			d[i].Xuat();
	return 0;
}
void TieuDe(string x){
	cout<<"+"<<setfill('-')<<setw(60)<<"+"<<setfill(' ')<<endl;
	cout<<"|"<<setw(30)<<"Ten";
	cout<<"|"<<setw(14)<<"Gia thanh";
	cout<<"|"<<setw(13)<<x<<"|"<<endl;
	cout<<"+"<<setfill('-')<<setw(60)<<"+"<<setfill(' ')<<endl;
}
