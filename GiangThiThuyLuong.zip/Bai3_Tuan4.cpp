#include<iostream>
#include<iomanip>

using namespace std;

class Mathang{
	protected:
		string mh, th;
		float dg;
	public:
		Mathang(){
			mh=" ";	th=" ";	dg=0;
		}
		Mathang(string mh, string th, float dg){
			this->mh = mh;
			this->th = th;
			this->dg =dg;
		}
		~Mathang(){	}
		friend istream& operator>>(istream& is, Mathang &mhg){
			fflush(stdin);
			cout<<"Ma hang: ";	getline(is, mhg.mh);
			cout<<"Ten hang: ";	getline(is, mhg.th);
			cout<<"Don gia: ";	cin>>mhg.dg;
			return is;
		}
};
class Banhkeo: public Mathang{
	private:
		string nsx;
	public:
		Banhkeo(){
			nsx = " ";
		}
		Banhkeo(string mh, string th, float dg, string nsx):Mathang(mh, th, dg){
			this->nsx = nsx;
		}
		~Banhkeo(){	}
		float chietKhau(){
			return(dg/100);
		}
		friend istream& operator>>(istream& is, Banhkeo &bk){
			is>>(Mathang&)bk;
			fflush(stdin);
			cout<<"Noi san xuat: ";	getline(is, bk.nsx);
			return is;
		}
		friend ostream& operator<<(ostream& os, Banhkeo &bk){
			os<<"|"<<setw(20)<<bk.mh;
			os<<"|"<<setw(30)<<bk.th;
			os<<"|"<<setw(10)<<bk.dg;
			os<<"|"<<setw(16)<<bk.nsx<<"|"<<endl;
			os<<"+"<<setfill('-')<<setw(80)<<"+"<<setfill(' ')<<endl;
			return os;
		}
		friend void khacMO1(Banhkeo bk[], int n);
};
void TieuDe();
int main(){
	int n;
	cout<<"Nhap n: ";	cin>>n;
	Banhkeo bk[n];
	
	cout<<"_NHAP DANH SACH BANH KEO_\n";
	for(int i=0; i<n; i++){
		cout<<"\tNhap thong tin san pham thu "<<i+1<<endl;
		cin>>bk[i];
	}
	
	cout<<"_DANH SACH BANH KEO CO MA KHAC 'MO1'_\n";
	khacMO1(bk, n);
	return 0;
}
void TieuDe(){
	cout<<"+"<<setfill('-')<<setw(80)<<"+"<<setfill(' ')<<endl;
	cout<<"|"<<setw(20)<<"Ma hang";
	cout<<"|"<<setw(30)<<"Ten hang";
	cout<<"|"<<setw(10)<<"Don gia";
	cout<<"|"<<setw(16)<<"Noi SX"<<"|"<<endl;
	cout<<"+"<<setfill('-')<<setw(80)<<"+"<<setfill(' ')<<endl;
}
void khacMO1(Banhkeo bk[], int n){
	TieuDe();
	for(int i=0; i<n; i++){
		if(bk[i].mh != "MO1")
			cout<<bk[i];
	}
}
