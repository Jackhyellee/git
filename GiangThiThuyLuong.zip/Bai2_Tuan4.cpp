#include<iostream>
#include<iomanip>

using namespace std;

typedef struct Birthday{
	int d, m, y;
}date;

class Mydate{
	protected:
		int d, m, y;
	public:
		Mydate(){
			d = 0; m = 0; y = 0;
		}
		Mydate(int d, int m, int y){
			this->d = d;
			this->m = m;
			this->y = y;
		}
		~Mydate(){	}
		void HienThi(){
			cout<<"|"<<setw(2)<<d<<"/"<<setw(2)<<m<<"/"<<left<<setw(4)<<y;	//10
		}
};
class Person: public Mydate{
	private:
		string name, add, phone;
	public:
		Person(){
			name = " ";	add = " ";	phone = " ";
		}
		Person(string name, date b, string add, string phone):Mydate(b.d, b.m, b.y){
			this->name = name;
			this->add = add;
			this->phone = phone;
		}
		~Person(){	}
		void Nhap(){
			cout<<"Ngay sinh: ";	cin>>d;
			cout<<"Thang sinh: ";	cin>>m;
			cout<<"Nam sinh: ";		cin>>y;
			cin.ignore();
			cout<<"Ho ten: ";		getline(cin, name);
			cout<<"Dia chi: ";		getline(cin, add);
			cout<<"Dien thoai: ";	getline(cin, phone);
		}
		void HienThi(){
			cout<<"|"<<setw(30)<<name;
			Mydate::HienThi();
			cout<<"|"<<setw(20)<<add;
			cout<<"|"<<setw(16)<<phone<<"|"<<endl;
			cout<<"+"<<setfill('-')<<setw(80)<<"+"<<setfill(' ')<<endl;
		}
		bool operator>(Person &p){
			return(y > p.y);
		}
};
void TieuDe();
int main(){
	int n;
	cout<<"Nhap n: ";	cin>>n;
	Person p[n];
	
	cout<<"_NHAP THONG TIN CUA MANG_\n";
	for(int i=0; i<n; i++){
		cout<<"\tNhap thong tin cua nguoi thu"<<i+1<<endl;
		p[i].Nhap();
	}
	
	cout<<"_DANH SACH GIAM DAN CUA NAM SINH_\n";
	TieuDe();
	for(int i=0; i<n; i++){
		Person max = p[i];
		for(int j=i+1; j<n; j++)
			if(p[j] > max)
				max = p[j];
		swap(p[i], max);
		p[i].HienThi();
	}
	
	cout<<"_DANH SACH TANG DAN CUA NAM SINH_\n";
	TieuDe();
	for(int i=0; i<n; i++){
		Person min = p[i];
		for(int j=i+1; j<n; j++)
			if(min > p[j])
				min = p[j];
		swap(p[i], min);
		p[i].HienThi();
	}
	return 0;
}
void TieuDe(){
	cout<<"+"<<setfill('-')<<setw(80)<<"+"<<setfill(' ')<<endl;
	cout<<"|"<<setw(30)<<"Ho ten";
	cout<<"|"<<setw(10)<<"Ngay sinh";
	cout<<"|"<<setw(20)<<"Dia chi";
	cout<<"|"<<setw(16)<<"Dien thoai"<<"|"<<endl;
	cout<<"+"<<setfill('-')<<setw(80)<<"+"<<setfill(' ')<<endl;
}
